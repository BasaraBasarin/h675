# G64 Goomba

Adds a **Goomba** (spawn menu → G64 → Enemies). The model, textures, skeleton, walk animation and
sounds are all read out of *your* Super Mario 64 (US) ROM at runtime. Nothing from the game is
included in this package, and without a valid ROM path the goomba does not spawn / does not draw.

## Why the binary module had to change
The Lua addon can't read the ROM; only `g64.dll` can. The stock module exposes 5 texture atlases
and no goomba data, so this package adds:

* `libsm64-gmod/src/load_goomba_data.{c,h}` – decodes the ROM's "common1" actor block (MIO0 @ `0x1F2200`)
  and extracts the goomba's display lists (vertices, UVs, normals, light colours), geo-layout bone
  offsets (`0x201018/0x201034/0x201054`) and its 30-frame walk animation. It validates the ROM
  (header string, MIO0 magic, geo opcodes, animation pointers) and fails cleanly if it isn't a US SM64 ROM.
* `sm64_goomba_load()` exported from libsm64, `libsm64.GetGoombaModel()` exported to Lua,
  and a 6th texture atlas (body sprite `0x19530`, face open `0x19D30`, face half-closed `0x1A530`).

## Build / install
1. Replace `src/libsm64.c`, `src/libsm64.h` and add `src/load_goomba_data.{c,h}` in `libsm64-gmod` (the Makefile picks up new `src/*.c` automatically), then `make`.
2. Copy the new `dist/` (dll + `include/libsm64.h`) to where the g64 module project expects it, replace `g64/main.cpp`, `g64/utils.cpp`, `g64/utils.h`, and rebuild `gmcl_g64_win64.dll`.
3. **Disable / avoid the addon's auto-updater for the module**, otherwise it will overwrite your custom DLL with the stock release.
4. Copy the contents of `addon-lua/` over the addon's `lua/` folder (3 new files: `entities/g64_goomba.lua`, `includes/g64_goomba_model.lua`; the rest are small edits, see `patches/`).

## Behaviour
* Targets the nearest player; normal (non-Mario) players are treated exactly like Mario.
* Mario: contact uses SM64's hitbox rules (radius 72×1.5 + 37, vertical overlap) and libsm64's own
  `MarioAttack` (stomp bounce, ground pound, punch/kick…) and `MarioTakeDamage` (knockback, cap rules, invincibility). Defeating it spawns the existing `g64_yellowcoin`.
* Normal players: 25 damage on side contact (1 s cooldown), die if you land on top (and you bounce).
* Goomba sounds (walk / alert / stomped / death) use the SM64 sound engine.

## Honest limitations
* **Not run in-game.** The ROM extraction was tested against your ROM (C and an independent Python implementation produce identical meshes; the atlas goes through libsm64's real texture loader). The Lua and the C++ module glue could not be executed/compiled here (no Lua runtime / Windows toolchain) – expect to fix small typos.
* The goomba's AI is machine code in the ROM that libsm64 doesn't run, so the AI is a Lua re-implementation of the decomp behaviour from memory. Constants I'm least sure of: jump height on alert, knockback speed, squish duration/scale (0.3), post-hit walk-away time.
* `PlaySoundGlobal` has no 3D positioning, so goomba sounds are simply culled beyond ~700 units.
* Lighting is the F3D formula (ambient + diffuse·N·L) baked per vertex and tinted by the map's light; no drop shadow.
