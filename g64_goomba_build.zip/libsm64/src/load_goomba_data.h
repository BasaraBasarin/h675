#pragma once

#include <stdint.h>
#include "libsm64.h"

// Returns 1 on success, 0 if the ROM does not look like a US Super Mario 64 ROM.
// All data is read from the player's own ROM at runtime; nothing is shipped.
extern int load_goomba_from_rom( const uint8_t *rom, struct SM64GoombaModel *out );
