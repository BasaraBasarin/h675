#include "load_goomba_data.h"

#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "decomp/tools/libmio0.h"

// ---------------------------------------------------------------------------
// US ROM locations.  Everything below was located by decoding the actor group
// "common1" (the MIO0 block loaded into segment 0x08) and following the
// goomba's geo layout / display lists / animation out of it.
// ---------------------------------------------------------------------------
#define ROM_COMMON1_MIO0        0x1F2200   // segment 8, decompresses to 0x28BF0 bytes
#define ROM_COMMON1_GEO         0x200FB4   // goomba geo layout lives in the raw geo area after the MIO0 block

#define GEO_SHADOW_ADDR         0x200FB4
#define GEO_SCALE_ADDR          0x200FC0
#define GEO_FACE_ADDR           0x201018   // ANIMATED_PART (48,0,0) + face DL
#define GEO_FOOT_L_ADDR         0x201034   // ANIMATED_PART (-60,-16, 45)
#define GEO_FOOT_R_ADDR         0x201054   // ANIMATED_PART (-60,-16,-45)

#define SEG8_DL_BILLBOARD       0x01B690   // 36x36 camera facing quad ("ball" body sprite)
#define SEG8_DL_FACE_OPEN       0x01B5C8
#define SEG8_DL_FACE_HALF       0x01B5F0
#define SEG8_DL_FOOT_L          0x01CE20
#define SEG8_DL_FOOT_R          0x01CF78
#define SEG8_ANIM_HEADER        0x01DA34
#define SEG8_ANIM_VALUES        0x01D770
#define SEG8_ANIM_INDEX         0x01D9D4

#define SEG8_TEX_BODY           0x019530
#define SEG8_TEX_FACE_OPEN      0x019D30
#define SEG8_TEX_FACE_HALF      0x01A530

static uint16_t be16( const uint8_t *p ) { return (uint16_t)((p[0] << 8) | p[1]); }
static int16_t  bs16( const uint8_t *p ) { return (int16_t)be16( p ); }
static uint32_t be32( const uint8_t *p ) { return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | p[3]; }

struct DlState
{
    const uint8_t *seg;     // decompressed segment 8
    uint32_t       segSize;
    struct SM64GoombaPart *part;
    uint32_t tex;
    float    ambient[3], diffuse[3], dir[3];
    // F3D vertex buffer
    struct { float p[3]; float uv[2]; float n[3]; } vb[32];
    int      vbValid[32];
    int      failed;
};

static int seg_ok( const struct DlState *s, uint32_t addr, uint32_t len )
{
    return ((addr >> 24) == 0x08) && ((addr & 0xFFFFFF) + len <= s->segSize);
}

static void run_dl( struct DlState *s, uint32_t off, int depth )
{
    if( depth > 8 ) { s->failed = 1; return; }

    for( ;; )
    {
        if( off + 8 > s->segSize ) { s->failed = 1; return; }
        const uint8_t *c = s->seg + off;
        off += 8;

        switch( c[0] )
        {
            case 0xB8: return; // G_ENDDL

            case 0x06: // G_DL
            {
                uint32_t a = be32( c + 4 );
                if( !seg_ok( s, a, 8 ) ) { s->failed = 1; return; }
                run_dl( s, a & 0xFFFFFF, depth + 1 );
                if( s->failed ) return;
                if( c[1] == 1 ) return; // branch, no return
                break;
            }

            case 0xFD: // G_SETTIMG
                s->tex = be32( c + 4 ) & 0xFFFFFF;
                break;

            case 0x03: // G_MOVEMEM (lights)
            {
                uint32_t a = be32( c + 4 );
                if( !seg_ok( s, a, 16 ) ) break;
                const uint8_t *l = s->seg + (a & 0xFFFFFF);
                if( c[1] == 0x86 ) // light 0 = directional
                {
                    for( int i = 0; i < 3; i++ ) s->diffuse[i] = l[i] / 255.0f;
                    float dx = (int8_t)l[8], dy = (int8_t)l[9], dz = (int8_t)l[10];
                    float len = sqrtf( dx*dx + dy*dy + dz*dz );
                    if( len > 0 ) { s->dir[0] = dx/len; s->dir[1] = dy/len; s->dir[2] = dz/len; }
                }
                else if( c[1] == 0x88 ) // light 1 = ambient
                {
                    for( int i = 0; i < 3; i++ ) s->ambient[i] = l[i] / 255.0f;
                }
                break;
            }

            case 0x04: // G_VTX
            {
                int n  = ((c[1] >> 4) & 0xF) + 1;
                int v0 = c[1] & 0xF;
                uint32_t a = be32( c + 4 );
                if( v0 + n > 32 || !seg_ok( s, a, (uint32_t)n * 16 ) ) { s->failed = 1; return; }
                for( int k = 0; k < n; k++ )
                {
                    const uint8_t *v = s->seg + (a & 0xFFFFFF) + k * 16;
                    int i = v0 + k;
                    s->vb[i].p[0]  = bs16( v + 0 );
                    s->vb[i].p[1]  = bs16( v + 2 );
                    s->vb[i].p[2]  = bs16( v + 4 );
                    s->vb[i].uv[0] = bs16( v + 8 )  / 32.0f / 32.0f;  // s10.5 texels -> 0..1 over a 32px texture
                    s->vb[i].uv[1] = bs16( v + 10 ) / 32.0f / 32.0f;
                    float nx = (int8_t)v[12], ny = (int8_t)v[13], nz = (int8_t)v[14];
                    float len = sqrtf( nx*nx + ny*ny + nz*nz );
                    if( len > 0 ) { nx /= len; ny /= len; nz /= len; }
                    s->vb[i].n[0] = nx; s->vb[i].n[1] = ny; s->vb[i].n[2] = nz;
                    s->vbValid[i] = 1;
                }
                break;
            }

            case 0xBF: // G_TRI1
            {
                int idx[3] = { c[5] / 10, c[6] / 10, c[7] / 10 };
                struct SM64GoombaPart *p = s->part;
                if( p->numVerts + 3 > SM64_GOOMBA_MAX_VERTS ) { s->failed = 1; return; }
                for( int k = 0; k < 3; k++ )
                {
                    int i = idx[k];
                    if( i < 0 || i >= 32 || !s->vbValid[i] ) { s->failed = 1; return; }
                    int o = p->numVerts + k;
                    memcpy( &p->position[o * 3], s->vb[i].p, sizeof(float) * 3 );
                    memcpy( &p->normal[o * 3],   s->vb[i].n, sizeof(float) * 3 );
                    memcpy( &p->uv[o * 2],       s->vb[i].uv, sizeof(float) * 2 );
                }
                p->numVerts += 3;
                break;
            }

            default: break; // pipe/tile/combine/other-mode commands do not matter for extraction
        }
    }
}

static int build_part( struct DlState *s, struct SM64GoombaPart *part, uint32_t dl, int bone, int texture, int billboard )
{
    memset( part, 0, sizeof(*part) );
    part->bone = bone;
    part->texture = texture;
    part->billboard = billboard;

    memset( s->vbValid, 0, sizeof(s->vbValid) );
    s->part = part;
    s->tex = 0;
    s->ambient[0] = s->ambient[1] = s->ambient[2] = 1.0f;
    s->diffuse[0] = s->diffuse[1] = s->diffuse[2] = 0.0f;
    s->dir[0] = s->dir[1] = s->dir[2] = 0.577f;

    run_dl( s, dl, 0 );
    if( s->failed || part->numVerts == 0 ) return 0;

    memcpy( part->ambient,  s->ambient, sizeof(float) * 3 );
    memcpy( part->diffuse,  s->diffuse, sizeof(float) * 3 );
    memcpy( part->lightDir, s->dir,     sizeof(float) * 3 );

    // cross-check: the texture the display list loaded must be the one we expect for this part
    uint32_t expect = (texture == 0) ? SEG8_TEX_BODY : (texture == 1) ? SEG8_TEX_FACE_OPEN : (texture == 2) ? SEG8_TEX_FACE_HALF : 0;
    if( texture >= 0 && s->tex != expect ) return 0;
    if( texture < 0 && s->tex != 0 ) return 0;
    return 1;
}

static int read_geo_part( const uint8_t *rom, uint32_t addr, int16_t out[3] )
{
    // GEO_ANIMATED_PART: 13 layer x y z dl
    if( rom[addr] != 0x13 ) return 0;
    out[0] = bs16( rom + addr + 2 );
    out[1] = bs16( rom + addr + 4 );
    out[2] = bs16( rom + addr + 6 );
    return 1;
}

int load_goomba_from_rom( const uint8_t *rom, struct SM64GoombaModel *out )
{
    memset( out, 0, sizeof(*out) );

    // --- sanity checks so a wrong ROM region/version fails cleanly instead of producing garbage
    if( memcmp( rom + 0x20, "SUPER MARIO 64", 14 ) != 0 ) return 0;
    if( memcmp( rom + ROM_COMMON1_MIO0, "MIO0", 4 ) != 0 ) return 0;
    if( rom[GEO_SHADOW_ADDR] != 0x16 || rom[GEO_SCALE_ADDR] != 0x1D ) return 0;

    // --- decompress segment 8
    mio0_header_t head;
    if( !mio0_decode_header( rom + ROM_COMMON1_MIO0, &head ) ) return 0;
    if( head.dest_size < 0x1E000 ) return 0;
    uint8_t *seg = (uint8_t*)malloc( head.dest_size );
    if( seg == NULL ) return 0;
    if( mio0_decode( rom + ROM_COMMON1_MIO0, seg, NULL ) < 0 ) { free( seg ); return 0; }

    int ok = 0;
    struct DlState *s = (struct DlState*)calloc( 1, sizeof(struct DlState) );
    if( s == NULL ) { free( seg ); return 0; }
    s->seg = seg;
    s->segSize = head.dest_size;

    // --- skeleton from the geo layout
    int16_t face[3], footL[3], footR[3];
    if( !read_geo_part( rom, GEO_FACE_ADDR, face ) ) goto done;
    if( !read_geo_part( rom, GEO_FOOT_L_ADDR, footL ) ) goto done;
    if( !read_geo_part( rom, GEO_FOOT_R_ADDR, footR ) ) goto done;

    out->scale = be32( rom + GEO_SCALE_ADDR + 4 ) / 65536.0f;

    // bone 0 root, 1 body, 2 face, 3 left foot pivot, 4 left foot, 5 right foot pivot, 6 right foot
    static const int parents[SM64_GOOMBA_NUM_BONES] = { -1, 0, 1, 1, 3, 1, 5 };
    memcpy( out->boneParent, parents, sizeof(parents) );
    out->boneOffset[2][0] = face[0];  out->boneOffset[2][1] = face[1];  out->boneOffset[2][2] = face[2];
    out->boneOffset[3][0] = footL[0]; out->boneOffset[3][1] = footL[1]; out->boneOffset[3][2] = footL[2];
    out->boneOffset[5][0] = footR[0]; out->boneOffset[5][1] = footR[1]; out->boneOffset[5][2] = footR[2];

    // --- geometry
    out->numParts = 5;
    if( !build_part( s, &out->parts[0], SEG8_DL_BILLBOARD,  1, 0,  1 ) ) goto done;
    if( !build_part( s, &out->parts[1], SEG8_DL_FACE_OPEN,  2, 1,  0 ) ) goto done;
    if( !build_part( s, &out->parts[2], SEG8_DL_FACE_HALF,  2, 2,  0 ) ) goto done;
    if( !build_part( s, &out->parts[3], SEG8_DL_FOOT_L,     4, -1, 0 ) ) goto done;
    if( !build_part( s, &out->parts[4], SEG8_DL_FOOT_R,     6, -1, 0 ) ) goto done;

    // --- animation
    {
        const uint8_t *h = seg + SEG8_ANIM_HEADER;
        int numFrames = bs16( h + 8 );  // loop end
        int bones     = bs16( h + 10 );
        if( be32( h + 12 ) != (0x08000000u | SEG8_ANIM_VALUES) ) goto done;
        if( be32( h + 16 ) != (0x08000000u | SEG8_ANIM_INDEX) ) goto done;
        if( bones != SM64_GOOMBA_NUM_BONES || numFrames <= 0 || numFrames > SM64_GOOMBA_MAX_FRAMES ) goto done;
        out->numFrames = numFrames;

        const uint8_t *values = seg + SEG8_ANIM_VALUES;
        const uint8_t *index  = seg + SEG8_ANIM_INDEX;
        for( int f = 0; f < numFrames; f++ )
        {
            int16_t v[3 + SM64_GOOMBA_NUM_BONES * 3];
            for( int k = 0; k < 3 + SM64_GOOMBA_NUM_BONES * 3; k++ )
            {
                uint16_t count  = be16( index + k * 4 );
                uint16_t offset = be16( index + k * 4 + 2 );
                int fi = f < (int)count ? f : (int)count - 1;
                v[k] = bs16( values + (offset + fi) * 2 );
            }
            for( int a = 0; a < 3; a++ ) out->rootTrans[f][a] = v[a];
            for( int b = 0; b < SM64_GOOMBA_NUM_BONES; b++ )
                for( int a = 0; a < 3; a++ )
                    out->rot[f][b][a] = v[3 + b * 3 + a] * (6.28318530718f / 65536.0f);
        }
    }
    ok = 1;

done:
    free( s );
    free( seg );
    if( !ok ) memset( out, 0, sizeof(*out) );
    return ok;
}
