# Build the DLLs without installing anything

1. Create a new (private is fine) repository on github.com and upload the contents of this folder
   (keep the hidden `.github` folder; with the web uploader, drag the folder contents in, or use git).
2. Open the **Actions** tab -> "Build G64 DLLs" -> **Run workflow** (it also runs on every push).
3. When it finishes (~5-10 min), open the run and download the artifact **g64-goomba-dlls**.
   It contains `sm64.dll`, `gmcl_g64_win64.dll` and `SDL2.dll`.
4. Install: back up your existing files first, then
   - `gmcl_g64_win64.dll` -> `GarrysMod/garrysmod/lua/bin/`
   - `sm64.dll` (and `SDL2.dll` if missing) -> the same folder where the G64 installer put its own `sm64.dll`
   - contents of `addon-lua/` -> over the addon's `lua/` folder
5. Disable the module auto-updater (or delete `gmcl_g64_updater_win64.dll`), otherwise it replaces your DLL.

If the build fails, open the failed step in the Actions log and send me the error text.
