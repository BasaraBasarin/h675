AddCSLuaFile()

-- Goomba model/animation renderer.
-- Everything it draws (mesh, textures, skeleton, walk animation, lighting colours) comes from the
-- user's ROM through libsm64.GetGoombaModel(); nothing is bundled with the addon.

g64goomba = g64goomba or {}

if CLIENT then
    local sin, cos, floor, max, min = math.sin, math.cos, math.floor, math.max, math.min

    g64goomba.Model = nil
    g64goomba.Warned = false

    -- Fetch (and cache) the model out of the module. Returns nil if unavailable.
    function g64goomba.GetModel()
        if g64goomba.Model then return g64goomba.Model end
        if libsm64 == nil or not libsm64.ModuleLoaded or not libsm64.IsGlobalInit() then return nil end
        if libsm64.GetGoombaModel == nil then
            if not g64goomba.Warned then
                g64goomba.Warned = true
                chat.AddText(Color(255, 100, 100), "[G64] Your g64 module is too old for goombas. Rebuild it with the goomba patch (see README_GOOMBA.md).")
            end
            return nil
        end
        local m = libsm64.GetGoombaModel()
        if not m then
            if not g64goomba.Warned then
                g64goomba.Warned = true
                chat.AddText(Color(255, 100, 100), "[G64] Could not extract the goomba from your ROM (is it a US Super Mario 64 ROM?).")
            end
            return nil
        end
        g64goomba.Model = m
        return m
    end

    function g64goomba.Reset() g64goomba.Model = nil; g64goomba.Warned = false end

    ---------------------------------------------------------------------------
    -- Skeleton
    ---------------------------------------------------------------------------
    local function lerpAngle(a, b, t)
        local d = (b - a + math.pi) % (2 * math.pi) - math.pi
        return a + d * t
    end

    -- SM64 mtxf_rotate_xyz_and_translate, kept as (R, t) with row-vector convention: p' = p*R + t
    local function boneLocal(rx, ry, rz, tx, ty, tz)
        local sx, cx, sy, cy, sz, cz = sin(rx), cos(rx), sin(ry), cos(ry), sin(rz), cos(rz)
        return {
            cy*cz,            cy*sz,            -sy,
            sx*sy*cz - cx*sz, sx*sy*sz + cx*cz, sx*cy,
            cx*sy*cz + sx*sz, cx*sy*sz - sx*cz, cx*cy,
        }, tx, ty, tz
    end

    local function mul3(a, b) -- a*b for 3x3 row-major tables
        return {
            a[1]*b[1]+a[2]*b[4]+a[3]*b[7], a[1]*b[2]+a[2]*b[5]+a[3]*b[8], a[1]*b[3]+a[2]*b[6]+a[3]*b[9],
            a[4]*b[1]+a[5]*b[4]+a[6]*b[7], a[4]*b[2]+a[5]*b[5]+a[6]*b[8], a[4]*b[3]+a[5]*b[6]+a[6]*b[9],
            a[7]*b[1]+a[8]*b[4]+a[9]*b[7], a[7]*b[2]+a[8]*b[5]+a[9]*b[8], a[7]*b[3]+a[8]*b[6]+a[9]*b[9],
        }
    end

    -- Returns an array of 7 bones { R = {9}, x, y, z } in model space for a (fractional) animation frame.
    function g64goomba.PoseBones(model, frame)
        local n = model.numFrames
        local f0 = floor(frame) % n
        local f1 = (f0 + 1) % n
        local t = frame - floor(frame)

        local bones = {}
        for b = 1, 7 do
            local r0, r1 = model.rot[f0 + 1][b], model.rot[f1 + 1][b]
            local rx, ry, rz = lerpAngle(r0.x, r1.x, t), lerpAngle(r0.y, r1.y, t), lerpAngle(r0.z, r1.z, t)
            local off
            if b == 1 then
                local a, c = model.rootTrans[f0 + 1], model.rootTrans[f1 + 1]
                off = Vector(a.x + (c.x - a.x) * t, a.y + (c.y - a.y) * t, a.z + (c.z - a.z) * t)
            else
                off = model.boneOffset[b]
            end
            local R, tx, ty, tz = boneLocal(rx, ry, rz, off.x, off.y, off.z)
            local parent = model.boneParent[b]
            if parent > 0 then
                local P = bones[parent]
                local pr = P.R
                -- t_world = t*Rp + tp ; R_world = R*Rp
                local wx = tx*pr[1] + ty*pr[4] + tz*pr[7] + P.x
                local wy = tx*pr[2] + ty*pr[5] + tz*pr[8] + P.y
                local wz = tx*pr[3] + ty*pr[6] + tz*pr[9] + P.z
                bones[b] = { R = mul3(R, pr), x = wx, y = wy, z = wz }
            else
                bones[b] = { R = R, x = tx, y = ty, z = tz }
            end
        end
        return bones
    end

    ---------------------------------------------------------------------------
    -- Drawing
    ---------------------------------------------------------------------------
    local lightDirWorld = Vector(0.577, 0.577, 0.577)

    -- state fields: pos (Source), yaw (SM64 radians), scale (SM64 obj scale), squish (Y scale), frame, face (1|2), alpha
    function g64goomba.Draw(state)
        local model = g64goomba.GetModel()
        if not model or g64utils.GoombaMats == nil then return end
        local sf = libsm64 and libsm64.ScaleFactor or 2.5

        local bones = g64goomba.PoseBones(model, state.frame)
        local k = model.scale * state.scale          -- model units -> SM64 world units
        local ky = k * state.squish
        local ca, sa = cos(state.yaw), sin(state.yaw)
        local pos = state.pos
        local eyeAng = EyeAngles()
        local camRight, camUp = eyeAng:Right(), eyeAng:Up()

        -- model space (SM64 units, before obj scale) -> Source world position
        local function toWorld(x, y, z)
            x, y, z = x * k, y * ky, z * k
            local wx = x * ca + z * sa
            local wz = -x * sa + z * ca
            return Vector(pos.x - wx / sf, pos.y + wz / sf, pos.z + y / sf)
        end
        local function rotNormal(nx, ny, nz) -- yaw only, no scale
            return nx * ca + nz * sa, ny, -nx * sa + nz * ca
        end

        local envColor = render.GetLightColor(pos + Vector(0, 0, 20))
        local env = Vector(min(1, envColor.x * 1.4 + 0.12), min(1, envColor.y * 1.4 + 0.12), min(1, envColor.z * 1.4 + 0.12))
        local alpha = state.alpha or 255

        for _, part in ipairs(model.parts) do
            local drawPart = true
            if part.texture == 1 and state.face ~= 1 then drawPart = false end
            if part.texture == 2 and state.face ~= 2 then drawPart = false end

            if drawPart then
                local mat = (part.texture >= 0) and g64utils.GoombaMats[part.texture + 1] or g64utils.GoombaVertsMat
                local bone = bones[part.bone]
                local R = bone.R
                local numVerts = #part.position
                local posT, nrmT, uv = part.position, part.normal, part.uv
                local amb, dif, ld = part.ambient, part.diffuse, part.lightDir
                local lx, ly, lz = ld.x, ld.y, ld.z

                render.SetMaterial(mat)
                mesh.Begin(MATERIAL_TRIANGLES, numVerts / 3)

                if part.billboard then
                    -- camera facing quad centred on the bone origin
                    local c = toWorld(bone.x, bone.y, bone.z)
                    local s = k / sf
                    for i = 1, numVerts do
                        local v = posT[i]
                        mesh.Position(c + camRight * (v.x * s) + camUp * (v.y * s))
                        mesh.Color(env.x * 255, env.y * 255, env.z * 255, alpha)
                        mesh.TexCoord(0, uv[i * 2 - 1], uv[i * 2])
                        mesh.AdvanceVertex()
                    end
                else
                    for i = 1, numVerts do
                        local v, nrm = posT[i], nrmT[i]
                        local px = v.x*R[1] + v.y*R[4] + v.z*R[7] + bone.x
                        local py = v.x*R[2] + v.y*R[5] + v.z*R[8] + bone.y
                        local pz = v.x*R[3] + v.y*R[6] + v.z*R[9] + bone.z
                        local nx = nrm.x*R[1] + nrm.y*R[4] + nrm.z*R[7]
                        local ny = nrm.x*R[2] + nrm.y*R[5] + nrm.z*R[8]
                        local nz = nrm.x*R[3] + nrm.y*R[6] + nrm.z*R[9]
                        nx, ny, nz = rotNormal(nx, ny, nz)

                        -- F3D lighting: ambient + diffuse * max(0, N.L)
                        local d = max(0, nx * lx + ny * ly + nz * lz)
                        local r = min(1, amb.x + dif.x * d)
                        local g = min(1, amb.y + dif.y * d)
                        local b = min(1, amb.z + dif.z * d)

                        mesh.Position(toWorld(px, py, pz))
                        mesh.Color(r * env.x * 255, g * env.y * 255, b * env.z * 255, alpha)
                        if part.texture >= 0 then mesh.TexCoord(0, uv[i * 2 - 1], uv[i * 2]) end
                        mesh.AdvanceVertex()
                    end
                end
                mesh.End()
            end
        end
    end
end
