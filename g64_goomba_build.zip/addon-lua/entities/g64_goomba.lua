AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_entity"

ENT.Category = "G64"
ENT.PrintName = "Goomba"
ENT.Author = "G64 goomba extension"
ENT.Spawnable = false
ENT.AdminSpawnable = true
ENT.AdminOnly = false

RegisterG64Entity(ENT, "g64_goomba")

include("includes/g64_utils.lua")
include("includes/g64_goomba_model.lua")

-------------------------------------------------------------------------------
-- Constants (SM64 units unless noted; Source units = SM64 units / g64_scale_factor)
-------------------------------------------------------------------------------
local OBJ_SCALE        = 1.5                -- regular goomba
local HITBOX_RADIUS    = 72  * OBJ_SCALE    -- sGoombaHitbox (object scale is applied by obj_set_hitbox)
local HITBOX_HEIGHT    = 50  * OBJ_SCALE
local MARIO_RADIUS     = 37
local MARIO_HEIGHT     = 160
local GRAVITY          = -8 / 3 * OBJ_SCALE -- per 30fps frame
local ALERT_RANGE      = 500
local HOME_RANGE       = 1000
local TURN_RATE        = 0x200 / 65536 * math.pi * 2
local JUMP_RATE        = 0x800 / 65536 * math.pi * 2
local STEP             = 1 / 30             -- SM64 logic rate

local ACT_WALK, ACT_ATTACKED_MARIO, ACT_JUMP, ACT_SQUISHED, ACT_KNOCKBACK = 0, 1, 2, 10, 11

local SND_WALK, SND_ALERT, SND_STOMPED, SND_DEATH = 1, 2, 3, 4
local INTERACT_HIT_MARIO, INTERACT_SQUISH, INTERACT_KNOCKBACK = 0, 1, 2

local scaleConVar = GetConVar("g64_scale_factor")
local function SF()
    if CLIENT and libsm64 and libsm64.ScaleFactor then return libsm64.ScaleFactor end
    return scaleConVar and scaleConVar:GetFloat() or 2.5
end

local function NormalizeAngle(a)
    return (a + math.pi) % (2 * math.pi) - math.pi
end

local function ApproachAngle(cur, target, rate)
    local d = NormalizeAngle(target - cur)
    if math.abs(d) <= rate then return target end
    return cur + (d > 0 and rate or -rate)
end

-- SM64 yaw (0 = +Z, towards +X) <-> Source direction. SM64 x = -Source x, SM64 z = Source y.
local function YawToDir(yaw) return Vector(-math.sin(yaw), math.cos(yaw), 0) end

-------------------------------------------------------------------------------
-- Shared
-------------------------------------------------------------------------------
function ENT:GetSquish() return self:GetNWFloat("G64SquishY", 1) end

function ENT:GetHitboxHeightSrc() return HITBOX_HEIGHT * self:GetSquish() / SF() end

function ENT:Initialize()
    local sf = SF()
    self.HullR = 52 / sf                    -- ~ visible head radius * object scale
    self.HullH = 117 / sf                   -- ~ visible model height * object scale

    self:SetModel("models/props_phx/misc/soccerball.mdl") -- invisible placeholder, we draw our own mesh
    self:SetMoveType(MOVETYPE_NONE)
    self:SetSolid(SOLID_BBOX)
    self:SetCollisionGroup(COLLISION_GROUP_NPC)
    self:SetCollisionBounds(Vector(-self.HullR, -self.HullR, 0), Vector(self.HullR, self.HullR, self.HullH))

    if SERVER then
        self:SetHealth(0) -- keeps Mario generic "living entity" attack traces from also hitting it; the goomba handles interactions itself
        self:SetNWFloat("G64SquishY", 1)
        self:SetNWFloat("G64Yaw", 0)
        self:SetNWFloat("G64Anim", 0)
        self:SetNWInt("G64Act", ACT_WALK)

        self.st = {
            act = ACT_WALK, timer = 0, yaw = math.Rand(0, math.pi * 2), targetYaw = 0,
            fwdVel = 0, relSpeed = 0, velY = 0, onGround = false, turningAway = false,
            walkTimer = 0, anim = 0, home = self:GetPos(), nextStep = CurTime(),
            lastFootstep = 0, deathVel = Vector(), spin = 0, hitUntil = 0,
        }
        self.st.targetYaw = self.st.yaw
    else
        self:SetRenderBounds(Vector(-80, -80, -10), Vector(80, 80, 120))
        g64utils.GlobalInit()
        self.DrawYaw = nil
        self.BlinkNext = CurTime() + math.Rand(1, 1.7)
        self.BlinkEnd = 0
        self.NextInteract = 0
    end
end

function ENT:UpdateTransmitState() return TRANSMIT_ALWAYS end

-------------------------------------------------------------------------------
-- SERVER: AI, movement, interactions
-------------------------------------------------------------------------------
if SERVER then
    -- Spawning requires the spawner's ROM (the goomba is read out of it). Reported by the client in g64utils.GlobalInit.
    function ENT:SpawnFunction(ply, tr, ClassName)
        if not tr.Hit then return end
        if not ply.G64HasROM then
            ply:ChatPrint("[G64] The goomba is read from your Super Mario 64 ROM. Set a valid ROM path in the G64 settings first.")
            return
        end

        local ent = ents.Create(ClassName)
        ent:SetOwner(ply)
        ent:SetPos(tr.HitPos + tr.HitNormal * 8)
        ent:Spawn()
        ent:Activate()
        return ent
    end

    local function BroadcastSound(ent, id)
        net.Start("G64_GOOMBASOUND", true)
            net.WriteEntity(ent)
            net.WriteUInt(id, 3)
        net.Broadcast()
    end

    local function SM64Dist3D(a, b) return a:Distance(b) * SF() end

    -- nearest living player; Mario players and normal players are treated identically ("detect you as Mario")
    function ENT:FindTarget(pos)
        local best, bestDist
        for _, ply in ipairs(player.GetAll()) do
            if ply:Alive() and ply:GetMoveType() ~= MOVETYPE_NOCLIP then
                local d = SM64Dist3D(pos, ply:GetPos())
                if not bestDist or d < bestDist then best, bestDist = ply, d end
            end
        end
        return best, bestDist
    end

    local function AngleTo(from, to)
        local sf = SF()
        local dx = -(to.x - from.x) * sf
        local dz = (to.y - from.y) * sf
        return math.atan2(dx, dz)
    end

    local function RandomLinearOffset(base, range) return base + math.random(0, range) end

    local up = Vector(0, 0, 1)
    local STEP_H = 18

    local function Hull(self)
        return Vector(-self.HullR, -self.HullR, 0), Vector(self.HullR, self.HullR, self.HullH - STEP_H)
    end

    -- world + props block the goomba; players and G64 entities (coins, other goombas...) do not
    local function WorldFilter(self)
        return function(e) return e ~= self and not e:IsPlayer() and not string.StartWith(e:GetClass(), "g64_") end
    end

    -- Horizontal + vertical movement with world collisions. Returns wallHit, edgeHit
    function ENT:MoveObject()
        local st = self.st
        local sf = SF()
        local pos = self:GetPos()
        local mins, maxs = Hull(self)
        local filter = WorldFilter(self)
        local wall, edge = false, false

        -- horizontal
        if st.fwdVel ~= 0 then
            local dir = YawToDir(st.yaw)
            local target = pos + dir * (st.fwdVel / sf)
            local tr = util.TraceHull({
                start = pos + up * STEP_H, endpos = target + up * STEP_H,
                mins = mins, maxs = maxs, filter = filter, mask = MASK_SOLID,
            })
            if tr.Hit and tr.Fraction < 1 then
                wall = true
                target = tr.HitPos - up * STEP_H
            else
                -- ledge check: goombas turn around instead of walking off edges
                if st.onGround and st.act == ACT_WALK then
                    local ahead = target + dir * (self.HullR * 0.6)
                    local tr2 = util.TraceLine({ start = ahead + up * 8, endpos = ahead - up * (STEP_H + 100 / sf), mask = MASK_SOLID, filter = filter })
                    if not tr2.Hit then edge = true; target = pos end
                end
            end
            pos = Vector(target.x, target.y, pos.z)
        end

        -- vertical
        if not st.onGround or st.velY > 0 then st.velY = math.max(st.velY + GRAVITY, -75) end
        local dz = st.velY / sf
        local fm = Vector(-self.HullR, -self.HullR, 0)
        local fx = Vector(self.HullR, self.HullR, 2)
        if st.velY > 0 then
            st.onGround = false
            pos.z = pos.z + dz
        else
            local reach = (-dz) + STEP_H + (st.onGround and 10 or 0)
            local tr = util.TraceHull({
                start = pos + up * STEP_H, endpos = pos - up * reach,
                mins = fm, maxs = fx, filter = filter, mask = MASK_SOLID,
            })
            if tr.StartSolid then
                pos.z = pos.z + 4 -- spawned/pushed inside geometry: lift out of it
                st.velY = 0
            elseif tr.Hit and tr.HitPos.z <= pos.z + STEP_H then
                pos.z = tr.HitPos.z
                st.velY = 0
                st.onGround = true
            else
                st.onGround = false
                pos.z = pos.z + dz
            end
        end

        self:SetPos(pos)
        return wall, edge
    end

    function ENT:SpawnCoin()
        local coin = ents.Create("g64_yellowcoin")
        if not IsValid(coin) then return end
        coin:SetPos(self:GetPos() + Vector(0, 0, 30))
        coin:Spawn()
        local phys = coin:GetPhysicsObject()
        if IsValid(phys) then
            phys:SetVelocity(Vector(math.random(-100, 100), math.random(-100, 100), math.random(200, 400)))
        end
    end

    function ENT:Die()
        ParticleEffect("mario_dust", self:GetPos() + Vector(0, 0, 10), Angle())
        self:SpawnCoin()
        self:Remove()
    end

    -- kind: INTERACT_SQUISH or INTERACT_KNOCKBACK; fromPos = attacker position
    function ENT:Kill(kind, fromPos)
        local st = self.st
        if st.act == ACT_SQUISHED or st.act == ACT_KNOCKBACK then return end
        st.timer = 0
        st.fwdVel = 0
        self:SetSolid(SOLID_NONE) -- intangible while dying
        if kind == INTERACT_SQUISH then
            st.act = ACT_SQUISHED
            self:SetNWFloat("G64SquishY", 0.3)
            BroadcastSound(self, SND_STOMPED)
        else
            st.act = ACT_KNOCKBACK
            local pos = self:GetPos()
            local away = fromPos and (pos - fromPos) or YawToDir(st.yaw)
            away.z = 0
            if away:LengthSqr() < 1 then away = YawToDir(st.yaw) end
            away:Normalize()
            st.deathVel = away
            st.yaw = math.atan2(-away.x, away.y)         -- face the way it is flying
            st.fwdVel = 30
            st.velY = 20
            st.onGround = false
            BroadcastSound(self, SND_DEATH)
        end
        self:SetNWInt("G64Act", st.act)
    end

    function ENT:HitMario()
        local st = self.st
        if st.act ~= ACT_WALK and st.act ~= ACT_JUMP then return end
        st.act = ACT_ATTACKED_MARIO
        st.timer = 0
        self:SetNWInt("G64Act", st.act)
    end

    -- Non-Mario players: 25 damage on touch, die if stomped.
    function ENT:InteractPlayers(pos)
        local st = self.st
        if st.act ~= ACT_WALK and st.act ~= ACT_JUMP and st.act ~= ACT_ATTACKED_MARIO then return end
        local sf = SF()
        local radius = HITBOX_RADIUS / sf + 16
        local gBottom = pos.z
        local gTop = pos.z + self:GetHitboxHeightSrc()
        for _, ply in ipairs(player.GetAll()) do
            if ply:Alive() and not ply.IsMario and ply:GetMoveType() ~= MOVETYPE_NOCLIP then
                local pp = ply:GetPos()
                local dx, dy = pp.x - pos.x, pp.y - pos.y
                if dx * dx + dy * dy < radius * radius then
                    local pBottom, pTop = pp.z, pp.z + 72
                    if pBottom < gTop + 8 and pTop > gBottom then
                        local vel = ply:GetVelocity()
                        local above = pBottom > gBottom + (gTop - gBottom) * 0.4
                        if above and (vel.z <= 40 or ply:GetGroundEntity() == self) then
                            -- stomp
                            ply:SetVelocity(Vector(0, 0, 360 - vel.z))
                            self:Kill(INTERACT_SQUISH, pp)
                            return
                        elseif CurTime() > (ply.G64GoombaHitUntil or 0) and not ply:HasGodMode() then
                            ply.G64GoombaHitUntil = CurTime() + 1
                            local d = DamageInfo()
                            d:SetDamage(25)
                            d:SetAttacker(self)
                            d:SetInflictor(self)
                            d:SetDamageType(DMG_CLUB)
                            d:SetDamagePosition(pos)
                            ply:TakeDamageInfo(d)
                            local away = pp - pos; away.z = 0; away:Normalize()
                            ply:SetVelocity(away * 250 + Vector(0, 0, 150))
                            self:HitMario()
                            return
                        end
                    end
                end
            end
        end
    end

    -- Weapons / other damage sources defeat it like a kick
    function ENT:OnTakeDamage(dmg)
        if not self.st then return 0 end
        local att = dmg:GetAttacker()
        self:Kill(INTERACT_KNOCKBACK, IsValid(att) and att:GetPos() or nil)
        return 0
    end

    function ENT:Step()
        local st = self.st
        local sf = SF()
        local pos = self:GetPos()
        st.timer = st.timer + 1

        local target, dist = self:FindTarget(pos)
        local angleToMario = target and AngleTo(pos, target:GetPos()) or st.yaw
        dist = dist or 25000

        -- treat_far_home_as_mario(1000)
        if pos:Distance(st.home) * sf > HOME_RANGE then
            angleToMario = AngleTo(pos, st.home)
            dist = 25000
        end

        local act = st.act
        if act == ACT_WALK then
            if st.turningAway then
                st.yaw = ApproachAngle(st.yaw, st.targetYaw, TURN_RATE)
                if math.abs(NormalizeAngle(st.targetYaw - st.yaw)) < 0.01 then st.turningAway = false end
            else
                if dist >= 25000 then
                    st.targetYaw = angleToMario
                    st.walkTimer = RandomLinearOffset(20, 30)
                end
                if dist < ALERT_RANGE then
                    if st.relSpeed <= 8 then
                        if st.relSpeed ~= 0 then BroadcastSound(self, SND_ALERT) end
                        st.act = ACT_JUMP
                        st.timer = 0
                        st.fwdVel = 0
                        st.velY = 50 / 3 * OBJ_SCALE
                        st.onGround = false
                        self:SetNWInt("G64Act", st.act)
                    else
                        st.targetYaw = angleToMario
                        st.relSpeed = 20
                    end
                else
                    st.relSpeed = 4
                    if st.walkTimer ~= 0 then
                        st.walkTimer = st.walkTimer - 1
                    else
                        if math.random(0, 3) ~= 0 then
                            st.targetYaw = st.yaw + math.Rand(-1, 1) * (0x2000 / 65536 * math.pi * 2)
                        end
                        st.walkTimer = RandomLinearOffset(100, 100)
                    end
                end
                st.yaw = ApproachAngle(st.yaw, st.targetYaw, TURN_RATE)
            end
            st.fwdVel = st.relSpeed / 4 * OBJ_SCALE

        elseif act == ACT_JUMP then
            st.yaw = ApproachAngle(st.yaw, angleToMario, JUMP_RATE)
            st.fwdVel = 0
            if st.onGround and st.timer > 2 then
                st.act = ACT_WALK
                st.relSpeed = 20
                st.targetYaw = angleToMario
                self:SetNWInt("G64Act", st.act)
            end

        elseif act == ACT_ATTACKED_MARIO then
            -- after hurting Mario the goomba turns away and wanders off for a moment
            st.targetYaw = angleToMario + math.pi
            st.yaw = ApproachAngle(st.yaw, st.targetYaw, TURN_RATE)
            st.relSpeed = 4
            st.fwdVel = OBJ_SCALE
            if st.timer > 40 then
                st.act = ACT_WALK
                st.targetYaw = st.yaw
                self:SetNWInt("G64Act", st.act)
            end

        elseif act == ACT_SQUISHED then
            st.fwdVel = 0
            if st.timer >= 20 then self:Die() return end

        elseif act == ACT_KNOCKBACK then
            st.spin = (st.spin or 0) + 0.6
            local wall = self:MoveObject()
            self:SetNWFloat("G64Yaw", st.yaw + st.spin)
            if wall or (st.onGround and st.timer > 2) or st.timer > 60 then self:Die() end
            return
        end

        local wall, edge = self:MoveObject()
        if (wall or edge) and st.act == ACT_WALK and not st.turningAway then
            -- bounce off walls/edges: turn around (mostly) and keep going
            st.turningAway = true
            st.targetYaw = st.yaw + math.pi + math.Rand(-0.5, 0.5)
            st.fwdVel = 0
        end

        -- goombas push each other apart
        for _, other in ipairs(ents.FindByClass("g64_goomba")) do
            if other ~= self then
                local d = other:GetPos() - self:GetPos(); d.z = 0
                local len = d:Length()
                local minD = self.HullR * 2
                if len > 0.1 and len < minD then
                    self:SetPos(self:GetPos() - d / len * (minD - len) * 0.5)
                end
            end
        end

        -- walk animation: speed follows forward velocity (animSpeed = fwdVel / scale * 0.4, min 1)
        local animSpeed = math.max(1, st.fwdVel / OBJ_SCALE * 0.4)
        if st.act == ACT_WALK or st.act == ACT_ATTACKED_MARIO then
            local prev = st.anim
            st.anim = (st.anim + animSpeed) % 30
            if st.onGround and st.fwdVel > 0 then
                if (prev < 15 and st.anim >= 15) or (prev > st.anim) then BroadcastSound(self, SND_WALK) end
            end
        end

        self:SetNWFloat("G64Yaw", st.yaw)
        self:SetNWFloat("G64Anim", st.anim)

        self:InteractPlayers(self:GetPos())
    end

    function ENT:Think()
        if not self.st then return end
        local now = CurTime()
        local guard = 0
        while now >= self.st.nextStep and guard < 3 do
            self.st.nextStep = self.st.nextStep + STEP
            self:Step()
            if not IsValid(self) then return end
            guard = guard + 1
        end
        if now - self.st.nextStep > 1 then self.st.nextStep = now end
        self:NextThink(CurTime())
        return true
    end

    -- Mario players' clients run the real libsm64 interaction and tell us the outcome
    net.Receive("G64_GOOMBAINTERACT", function(len, ply)
        local ent = net.ReadEntity()
        local kind = net.ReadUInt(2)
        if not IsValid(ent) or ent:GetClass() ~= "g64_goomba" or not ent.st then return end
        if not ply.IsMario then return end
        if ent:GetPos():Distance(ply:GetPos()) > 600 then return end

        if kind == INTERACT_HIT_MARIO then
            ent:HitMario()
        elseif kind == INTERACT_SQUISH or kind == INTERACT_KNOCKBACK then
            ent:Kill(kind, ply:GetPos())
        end
    end)
end

-------------------------------------------------------------------------------
-- CLIENT: rendering, sounds, Mario interaction
-------------------------------------------------------------------------------
if CLIENT then
    local MA = g64types.SM64MarioAction
    local squishActs = {
        [MA.ACT_GROUND_POUND] = true, [MA.ACT_TWIRLING] = true,
        [MA.ACT_GROUND_POUND_LAND] = true, [MA.ACT_TWIRL_LAND] = true,
    }
    local ACT_FLAG_ATTACKING = g64types.SM64MarioActionFlags.ACT_FLAG_ATTACKING
    local ACT_FLAG_AIR = g64types.SM64MarioActionFlags.ACT_FLAG_AIR

    local soundIds = {
        [SND_WALK] = "SOUND_OBJ_GOOMBA_WALK", [SND_ALERT] = "SOUND_OBJ_GOOMBA_ALERT",
        [SND_STOMPED] = "SOUND_OBJ_STOMPED", [SND_DEATH] = "SOUND_OBJ_DEFAULT_DEATH",
    }
    local SOUND_RANGE = 700 -- Source units; PlaySoundGlobal has no positional audio, so cull by distance

    net.Receive("G64_GOOMBASOUND", function()
        local ent = net.ReadEntity()
        local id = net.ReadUInt(3)
        if not IsValid(ent) or libsm64 == nil or not libsm64.ModuleLoaded or not libsm64.IsGlobalInit() then return end
        if ent:GetPos():Distance(LocalPlayer():GetPos()) > SOUND_RANGE then return end
        local snd = g64types.SM64SoundTable[soundIds[id]]
        if snd then libsm64.PlaySoundGlobal(GetSoundArg(snd)) end
    end)

    function ENT:Draw()
        local model = g64goomba.GetModel()
        if not model then return end

        local now = CurTime()
        local nwYaw = self:GetNWFloat("G64Yaw", 0)
        if self.DrawYaw == nil then self.DrawYaw = nwYaw end
        self.DrawYaw = ApproachAngle(self.DrawYaw, nwYaw, math.max(0.1, FrameTime() * 12))

        -- blinking: eyes open 30-50 frames, half closed for 5 frames
        if now >= self.BlinkNext then
            self.BlinkEnd = now + 5 / 30
            self.BlinkNext = self.BlinkEnd + math.random(30, 50) / 30
        end
        local face = (now < self.BlinkEnd) and 2 or 1

        g64goomba.Draw({
            pos = self:GetPos(),
            yaw = self.DrawYaw,
            scale = OBJ_SCALE,
            squish = self:GetSquish(),
            frame = self:GetNWFloat("G64Anim", 0),
            face = face,
        })
    end

    -- Interaction with the local Mario, using libsm64's own attack/damage code
    function ENT:InteractWithLocalMario()
        local ply = LocalPlayer()
        if not ply.IsMario then return end
        local mario = ply.MarioEnt
        if not IsValid(mario) or mario.MarioId == nil or mario.MarioId < 0 then return end
        local act = self:GetNWInt("G64Act", ACT_WALK)
        if act ~= ACT_WALK and act ~= ACT_JUMP and act ~= ACT_ATTACKED_MARIO then return end
        if CurTime() < self.NextInteract then return end

        local sf = libsm64.ScaleFactor
        local gpos = self:GetPos()
        local mpos = mario.marioPos
        if mpos == nil then return end

        -- SM64 check_object_collision: horizontal radius + vertical overlap of both boxes
        local dx, dy = mpos.x - gpos.x, mpos.y - gpos.y
        local radius = (HITBOX_RADIUS + MARIO_RADIUS) / sf
        if dx * dx + dy * dy >= radius * radius then return end
        local gTop = gpos.z + HITBOX_HEIGHT * self:GetSquish() / sf
        local mTop = mpos.z + MARIO_HEIGHT / sf
        if not (mpos.z < gTop and mTop > gpos.z) then return end

        self.NextInteract = CurTime() + 1 / 30

        -- classify before MarioAttack mutates Mario (SM64: ground pound / twirl / from above squish, everything else knocks back)
        local action = mario.marioAction or 0
        local attacking = bit.band(action, ACT_FLAG_ATTACKING) ~= 0 or mario.hasMetalCap == true
        local kind = INTERACT_SQUISH
        if squishActs[action] then
            kind = INTERACT_SQUISH
        elseif attacking then
            kind = INTERACT_KNOCKBACK
        end

        if libsm64.MarioAttack(mario.MarioId, gpos, HITBOX_HEIGHT * self:GetSquish() / sf) == true then
            self.NextInteract = CurTime() + 0.5
            net.Start("G64_GOOMBAINTERACT")
                net.WriteEntity(self)
                net.WriteUInt(kind, 2)
            net.SendToServer()
        elseif (mario.marioInvincTimer or 0) < 1 and not mario.hasVanishCap and act ~= ACT_ATTACKED_MARIO then
            -- goomba damage value is 1
            libsm64.MarioTakeDamage(mario.MarioId, 1, 0, gpos)
            self.NextInteract = CurTime() + 0.5
            net.Start("G64_GOOMBAINTERACT")
                net.WriteEntity(self)
                net.WriteUInt(INTERACT_HIT_MARIO, 2)
            net.SendToServer()
        end
    end

    function ENT:Think()
        if libsm64 ~= nil and libsm64.ModuleLoaded and libsm64.IsGlobalInit() then
            self:InteractWithLocalMario()
        end
        self:SetNextClientThink(CurTime())
        return true
    end
end

-------------------------------------------------------------------------------
-- Spawn menu entry
-------------------------------------------------------------------------------
list.Set("g64_entities", "g64_goomba", {
    Category = "Enemies",
    Name = "Goomba",
    Material = "",
    IconGenerator = {
        material = g64utils.GoombaMats and g64utils.GoombaMats[2] or nil,
        u = { 0, 1 },
        v = { 0, 1 },
    }
})
